<!DOCTYPE html>
            <html>
            <head>
            <title>Vintage Car Auction System</title>
            </head>
            <body>
            <h3>Dear <?php echo e($data["U_Name"]); ?>,</h3> <br>
            <h2>Your registration is confirmed successfully. You can log in your account.</h2><br>
            <p>With Regards,</p>
            <p>Vintage Car Auction System</p>
            </body>
 	</html><?php /**PATH C:\xampp\htdocs\VCAS_Project\resources\views/mailService.blade.php ENDPATH**/ ?>