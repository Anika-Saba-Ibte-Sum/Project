
<?php $__env->startSection('content'); ?>

    <?php if(Session::get('user')): ?> <?php echo e(Session::get('user')); ?>

    <a class="btn btn-primary" href="<?php echo e(route('wantSeller')); ?>">Want to be a seller?</a>      
        
    <?php endif; ?> 
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\VCAS_Project\resources\views/userDash.blade.php ENDPATH**/ ?>