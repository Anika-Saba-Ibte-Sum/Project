
<footer class="footer-part">
        <div class="footer-container">
            <p>Copyright &copy; 2022</p>
        </div>
    </footer>

</body>
</html><?php /**PATH C:\xampp\htdocs\VCAS_Project\resources\views/navitems/footer.blade.php ENDPATH**/ ?>