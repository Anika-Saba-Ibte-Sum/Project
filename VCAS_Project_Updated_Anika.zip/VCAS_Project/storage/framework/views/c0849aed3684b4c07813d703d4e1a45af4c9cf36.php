
<?php $__env->startSection('content'); ?>

    <?php if(Session::get('user')): ?> <?php echo e(Session::get('user')); ?>


    <table class="table table-border">
    <tr>
        <th>U_Id</th>
        <th>Description</th>
        <th>Status</th>
    </tr>
    <?php $__currentLoopData = $complaints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $complaint): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($complaint->U_Id); ?></td>
            <td><?php echo e($complaint->Description); ?></td>
            <td><?php echo e($complaint->Status); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
        
    <?php endif; ?> 
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.appAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\VCAS_Project\resources\views/admin/userComplains.blade.php ENDPATH**/ ?>