
<?php $__env->startSection('content'); ?>

    <?php if(Session::get('user')): ?> <?php echo e(Session::get('user')); ?>


    <table class="table table-border">
    <tr>
        <th>Start Amount</th>
        <th>Final Amount</th>
        <th>Win Status</th>
    </tr>
    <?php $__currentLoopData = $auctions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $auction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($auction->Start_Amount); ?></td>
            <td><?php echo e($auction->Final_Amount); ?></td>
            <td><?php echo e($auction->Win_Status); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
        
    <?php endif; ?> 
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.appAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\VCAS_Project\resources\views/admin/auctionDetails.blade.php ENDPATH**/ ?>