
<?php $__env->startSection('content'); ?>

<?php if(Session::get('user')): ?> <?php echo e(Session::get('user')); ?> 
 <h1>Profile</h1>       
<form action="<?php echo e(route('viewProfile')); ?>" class="form-group" method="post" enctype="multipart/form-data">

    <?php echo e(csrf_field()); ?>


    <div class="col-md-4 form-group" >
        <span>Name</span>
        <input type="text" name="U_Name" value="<?php echo e($user->U_Name); ?>" class="form-control">
        
    </div>
    <div class="col-md-4 form-group">
        <span>Email</span>
        <input type="text" name="U_Email" value="<?php echo e($user->U_Email); ?>" class="form-control">
        
    </div>
    
    <div class="col-md-4 form-group">
        <span>Phone</span>
        <input type="text" name="U_Phn" value="<?php echo e($user->U_Phn); ?>" class="form-control">
        
    </div>
    <div class="col-md-4 form-group">
        <span>Date of Birth</span>
        <input type="date" name="U_Dob" value="<?php echo e($user->U_Dob); ?>" class="form-control">
        
    </div>
   
    <div class="col-md-4 form-group">
        <span>Photo</span>
        <input type="file" name="U_Photo" value="<?php echo e($user->U_Photo); ?>" class="form-control">
        
    </div>
    <br>
    <input type="submit" class="btn btn-success" value="Edit" href="<?php echo e(route('editProfile')); ?>">  
                  
</form>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\VCAS_Project\resources\views/viewProfile.blade.php ENDPATH**/ ?>