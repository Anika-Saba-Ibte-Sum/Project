
<?php $__env->startSection('content'); ?>
<br><h1>Login</h1><br>
<form action="<?php echo e(route('login')); ?>" class="form-group" method="post">
    <?php echo e(csrf_field()); ?>


    <div class="col-md-4 form-group">
        <span>Email</span>
        <input type="text" name="U_Email" value="<?php echo e(old('U_Email')); ?>" class="form-control">
        <?php $__errorArgs = ['U_Email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-md-4 form-group">
        <span>Password</span>
        <input type="password" name="U_Pass" value="<?php echo e(old('U_Pass')); ?>" class="form-control">
        <?php $__errorArgs = ['U_Pass'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
   
    <input type="checkbox" id="me" name="rem_me" value="Remember Me">
      <label for="remember me"> Remember Me</label><br><br>
    <input type="submit" class="btn btn-success" value="Sign In" > 
    <a href="<?php echo e(route('forgetPass')); ?>"><span class="blue">Forget Password?</span></a>
                     
</form>


<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\VCAS_Project\resources\views/login.blade.php ENDPATH**/ ?>