
<?php $__env->startSection('content'); ?>

    <?php if(Session::get('user')): ?> <?php echo e(Session::get('user')); ?>


       
    <table class="table table-border">
    <tr>
        <th>Admin Name</th>
        <th>Phone</th>
        <th>Email</th>
    </tr>
    <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($admin->A_Name); ?></td>
            <td><?php echo e($admin->A_Phone); ?></td>
            <td><?php echo e($admin->A_Email); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
        
    <?php endif; ?> 
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.appAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\VCAS_Project\resources\views/admin/adminList.blade.php ENDPATH**/ ?>