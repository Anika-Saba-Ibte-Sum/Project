
<?php $__env->startSection('content'); ?>

<?php if(Session::get('user')): ?> <?php echo e(Session::get('user')); ?> 
        
<form action="<?php echo e(route('editProfile')); ?>" class="form-group" method="post" enctype="multipart/form-data">

    <?php echo e(csrf_field()); ?>


    <div class="col-md-4 form-group" >
        <span>Name</span>
        <input type="text" name="U_Name" value="<?php echo e($user->U_Name); ?>" class="form-control">
        <?php $__errorArgs = ['U_Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-md-4 form-group">
        <span>Email</span>
        <input type="text" name="U_Email" value="<?php echo e($user->U_Email); ?>" class="form-control">
        <?php $__errorArgs = ['U_Email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    
    <div class="col-md-4 form-group">
        <span>Phone</span>
        <input type="text" name="U_Phn" value="<?php echo e($user->U_Phn); ?>" class="form-control">
        <?php $__errorArgs = ['U_Phn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-md-4 form-group">
        <span>Date of Birth</span>
        <input type="date" name="U_Dob" value="<?php echo e($user->U_Dob); ?>" class="form-control">
        <?php $__errorArgs = ['U_Dob'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    
    
    <div class="col-md-4 form-group">
        <span>Photo</span>
        <input type="file" name="U_Photo" value="<?php echo e($user->U_Photo); ?>" class="form-control">
        <?php $__errorArgs = ['U_Photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <br>
    <input type="submit" class="btn btn-success" value="Save" >  
    <a class="btn btn-primary" href="<?php echo e(route('login')); ?>">Log In</a>                
</form>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\VCAS_Project\resources\views/editProfile.blade.php ENDPATH**/ ?>