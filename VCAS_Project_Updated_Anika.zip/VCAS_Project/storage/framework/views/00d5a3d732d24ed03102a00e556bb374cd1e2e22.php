
<?php $__env->startSection('content'); ?>

    <?php if(Session::get('user')): ?> <?php echo e(Session::get('user')); ?>


    
        
    <?php endif; ?> 
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.appAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\VCAS_Project\resources\views/admin/pendingDetails.blade.php ENDPATH**/ ?>