@extends('layouts.appAdmin')
@section('content')

    @if(Session::get('user')) {{Session::get('user')}}

    <table class="table table-border">
    <tr>
        <th>Start Amount</th>
        <th>Final Amount</th>
        <th>Win Status</th>
    </tr>
    @foreach($auctions as $auction)
        <tr>
            <td>{{$auction->Start_Amount}}</td>
            <td>{{$auction->Final_Amount}}</td>
            <td>{{$auction->Win_Status}}</td>
        </tr>
    @endforeach
</table>
        
    @endif 
@endsection 