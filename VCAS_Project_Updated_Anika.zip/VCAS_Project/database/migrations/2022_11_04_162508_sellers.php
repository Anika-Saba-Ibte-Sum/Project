<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('sellers', function (Blueprint $table) {
            $table->bigIncrements('id')->start_from(7000);

            $table->bigInteger('U_Id')->unsigned();
            $table->string('S_bankName');
            $table->Integer('S_accountNo');
            $table->Integer('Rating')->default('0');
            $table->foreign('U_Id')->references('id')->on('users')->onDelete('cascade');
            $table->index('U_Id');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('sellers');
    }
};
