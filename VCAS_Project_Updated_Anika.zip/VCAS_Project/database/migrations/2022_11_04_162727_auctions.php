<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('auctions', function (Blueprint $table) {
            $table->bigIncrements('id')->start_from(6000);
            $table->bigInteger('S_Id')->unsigned();
            $table->bigInteger('U_Id')->unsigned();
            $table->bigInteger('P_Id')->unsigned();          
            $table->double('Start_Amount');
            $table->double('Final_Amount')->nullable();
            $table->Integer('Win_Status')->default('0');
            $table->foreign('U_Id')->references('id')->on('users')->onDelete('cascade');
            $table->foreign('S_Id')->references('id')->on('sellers')->onDelete('cascade');
            $table->foreign('P_Id')->references('id')->on('payments')->onDelete('cascade');
            $table->index('U_Id');
            $table->index('S_Id');
            $table->index('P_Id');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('auctions');
    }
};
