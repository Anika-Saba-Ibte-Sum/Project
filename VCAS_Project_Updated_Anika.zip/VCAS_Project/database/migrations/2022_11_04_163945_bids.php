<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('bids', function (Blueprint $table) {
            $table->bigIncrements('id')->start_from(200);
            $table->bigInteger('P_Id')->unsigned();
            $table->bigInteger('Auction_Id')->unsigned();
            $table->double('Bid_Amount');
            $table->string('Bid_Time');
            $table->bigInteger('U_Id')->unsigned();
            $table->foreign('U_Id')->references('id')->on('users')->onDelete('cascade');
            $table->foreign('P_Id')->references('id')->on('payments')->onDelete('cascade');
            $table->foreign('Auction_Id')->references('id')->on('auctions')->onDelete('cascade');
            $table->index('U_Id');
            $table->index('P_Id');
            $table->index('Auction_Id');
           
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('bids');
    }
};
