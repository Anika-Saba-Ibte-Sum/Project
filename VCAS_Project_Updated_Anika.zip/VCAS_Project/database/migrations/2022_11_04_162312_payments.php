<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('payments', function (Blueprint $table) {
         $table->bigIncrements('id')->start_from(5000);

        $table->bigInteger('U_Id')->unsigned();
        $table->bigInteger('Auction_Id')->unsigned();
        $table->Integer('Account_No');

        $table->Integer('Verification_Status')->default('0');

        $table->string('Payment_Recipt');
        $table->foreign('U_Id')->references('id')->on('users')->onDelete('cascade');
        $table->index('U_Id');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('payments');
    }
};
