<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('products', function (Blueprint $table) {
            $table->bigIncrements('id')->start_from(9000);
            $table->bigInteger('S_Id')->unsigned();
            $table->bigInteger('Category_Id')->unsigned();
            $table->string('P_CarName');
            $table->string('P_Photo');
            $table->bigInteger('Car_Reg_Details_Id')->unsigned();
            $table->Integer('Valid_Status')->default('0');
            $table->foreign('Car_Reg_Details_Id')->references('id')->on('car_reg_details')->onDelete('cascade');
            $table->foreign('Category_Id')->references('id')->on('catagories')->onDelete('cascade');
            $table->foreign('S_Id')->references('id')->on('sellers')->onDelete('cascade');
            $table->index('S_Id');
            $table->index('Category_Id');
            $table->index('Car_Reg_Details_Id');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('products');
    }
};
